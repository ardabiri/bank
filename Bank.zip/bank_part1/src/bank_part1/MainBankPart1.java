package bank_part1;

public class MainBankPart1 {

	
		
		public static void main(String[] args) {
			Account alireza = new Account("alireza",1500,"001");
			Account zahra = new Account("zahra",2300,"002");
			Account majid = new Account("majid",4000,"006");
			Account amirhossein = new Account("amirhossein",3200,"003");
			Account sadra = new Account("sadra",2100,"021");
			Account maryam = new Account("maryam",2600,"025");
			Account []peoplelist = {alireza,zahra,majid,amirhossein,sadra,maryam};
			AccountServices list = new AccountServices(peoplelist);
			list.AccountSortBalance();
			list.AccountPrint();
			System.out.println(".......");
			list.AccountReverseSortBalance();
			list.AccountPrint();
			list.map();
			System.out.println(".......");
			list.deleteBasedOnBranch("002");
			
			

		}

	

}
