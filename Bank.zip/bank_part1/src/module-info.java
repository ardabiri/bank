/**
 * 
 */
/**
 * 
 */
module bank_part1 {
}