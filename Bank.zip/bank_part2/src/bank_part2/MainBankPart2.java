package bank_part2;



public class MainBankPart2 {

		public static void main(String[] args) {
			Account alireza = new Account("alireza",1500,"001");
			Account zahra = new Account("zahra",2300,"002");
			Account majid = new Account("majid",4000,"006");
			Account amirhossein = new Account("amirhossein",3200,"003");
			Account sadra = new Account("sadra",2100,"021");
			Account maryam = new Account("maryam",2600,"025");
			Account []peoplelist = {alireza,zahra,majid,amirhossein,sadra,maryam};
			FilterOnAccount list = new FilterOnAccount(peoplelist);
			list.toUpper();
			list.AStart();
			list.A_Balance();

		

	}

}
