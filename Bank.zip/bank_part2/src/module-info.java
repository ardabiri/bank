/**
 * 
 */
/**
 * 
 */
module bank_part2 {
}